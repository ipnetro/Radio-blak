package ro.ipnet.radiobigfmalban

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

private data class Station(val name: String, val subtitle: String, val url: String)
private val stations = listOf(
    Station("Radio Angel Hip-Hop", "HIP-HOP • LIVE", "https://radio.ip-net.ro/public/radio_angel_hip-hop/playlist.pls"),
    Station("Radio Big FM Alban", "ALBANIAN HITS • LIVE", "https://radio.ip-net.ro/public/radio_big_fm_alban/playlist.pls"),
    Station("Radio Tequila Club", "CLUB • LIVE", "https://radio.ip-net.ro/public/radio_tequila_club/playlist.pls")
)
private val Bg = Color(0xFF08090C)
private val Panel = Color(0xFF171820)
private val Red = Color(0xFFFF1744)

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, RadioPlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ controller = future.get() }, MoreExecutors.directExecutor())
    }

    override fun onStop() {
        controller?.release()
        controller = null
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Red, background = Bg, surface = Panel,
                onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
            )) {
                RadioScreen(controller)
            }
        }
    }
}

@Composable
private fun RadioScreen(controller: MediaController?) {
    var selected by remember { mutableIntStateOf(1) }
    var playing by remember { mutableStateOf(false) }
    var muted by remember { mutableStateOf(false) }
    var timerMinutes by remember { mutableIntStateOf(0) }
    var secondsLeft by remember { mutableIntStateOf(0) }

    LaunchedEffect(controller) {
        while (true) {
            playing = controller?.isPlaying == true
            delay(500)
        }
    }
    LaunchedEffect(timerMinutes) {
        if (timerMinutes > 0) {
            secondsLeft = timerMinutes * 60
            while (secondsLeft > 0) {
                delay(1000)
                secondsLeft--
            }
            controller?.pause()
            playing = false
            timerMinutes = 0
        }
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF260B13), Color(0xFF101117), Bg))
        )
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Text("IP•NET  RADIO", fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Surface(color = Color(0xFF35121D), shape = CircleShape) {
                    Text("● LIVE PLAYER", color = Color(0xFFFF6B86),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        fontSize = 10.sp, letterSpacing = 1.sp)
                }
            }
            Spacer(Modifier.height(38.dp))
            Box(
                Modifier.size(206.dp).background(
                    Brush.radialGradient(listOf(Color(0xFF33343D), Color(0xFF111218), Color(0xFF08090C))),
                    CircleShape
                ),
                contentAlignment = Alignment.Center
            ) {
                Surface(Modifier.size(176.dp), shape = CircleShape,
                    color = Color.Transparent, border = androidx.compose.foundation.BorderStroke(2.dp, Red.copy(alpha=.45f))) {}
                Text("FM", color = Red, fontSize = 52.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(25.dp))
            Text("Radio Big FM Alban", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("FEEL THE MUSIC  •  LIVE", color = Color.LightGray, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(24.dp))
            Surface(color = Panel, shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30313A)),
                modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text(stations[selected].name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(stations[selected].subtitle, color = Color.LightGray, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                OutlinedButton(onClick = { controller?.stop(); playing = false },
                    shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(52.dp)) { Text("■") }
                Button(
                    onClick = {
                        val c = controller ?: return@Button
                        if (c.isPlaying) { c.pause(); playing = false }
                        else {
                            c.setMediaItem(MediaItem.fromUri(stations[selected].url))
                            c.prepare()
                            c.play()
                            playing = true
                        }
                    },
                    shape = CircleShape, contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.size(78.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Red)
                ) { Text(if (playing) "Ⅱ" else "▶", fontSize = 28.sp) }
                OutlinedButton(onClick = { muted = !muted; controller?.volume = if (muted) 0f else 1f },
                    shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(52.dp)) {
                    Text(if (muted) "×" else "♫", fontSize = 18.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(if (controller == null) "Pregătire player..." else if (playing) "REDĂ LIVE" else "Pregătit pentru redare",
                color = Color(0xFFFF718A), fontSize = 12.sp)
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Text("SLEEP TIMER", color = Color.LightGray, fontSize = 11.sp, letterSpacing = 1.5.sp)
                Text(if (secondsLeft > 0) "%02d:%02d".format(secondsLeft/60, secondsLeft%60) else "OPRIT",
                    color = Red, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0, 15, 30, 60).forEach { mins ->
                    FilterChip(selected = timerMinutes == mins, onClick = { timerMinutes = mins },
                        label = { Text(if (mins == 0) "Off" else "${mins}m") })
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("ALEGE POSTUL", modifier = Modifier.fillMaxWidth(),
                color = Color.LightGray, fontSize = 11.sp, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(8.dp))
            stations.forEachIndexed { index, station ->
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                        .clickable {
                            selected = index
                            controller?.setMediaItem(MediaItem.fromUri(station.url))
                            controller?.prepare()
                            controller?.play()
                            playing = true
                        },
                    color = if (selected == index) Color(0xFF2B121B) else Panel,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp, if (selected == index) Red.copy(alpha=.8f) else Color(0xFF30313A)
                    )
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = Color(0xFF391521), shape = RoundedCornerShape(12.dp)) {
                            Text(listOf("AH", "BF", "TC")[index], color = Red,
                                modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Black)
                        }
                        Spacer(Modifier.width(13.dp))
                        Column(Modifier.weight(1f)) {
                            Text(station.name, fontWeight = FontWeight.SemiBold)
                            Text(station.subtitle, color = Color.LightGray, fontSize = 10.sp)
                        }
                        Text("›", color = Red, fontSize = 25.sp)
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Text("RADIO BIG FM ALBAN  •  BLACK / RED EDITION",
                color = Color.Gray, fontSize = 9.sp, letterSpacing = 1.sp)
        }
    }
}
