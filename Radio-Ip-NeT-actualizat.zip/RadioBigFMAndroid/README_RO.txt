Radio Big FM Alban - proiect Android nativ (Kotlin + Jetpack Compose + Media3).

Include:
- Radio Angel Hip-Hop
- Radio Big FM Alban
- Radio Tequila Club
- player Media3, redare prin serviciu MediaSessionService
- - interfață dark black/red

IMPORTANT:
Acesta este CODUL SURSA Android, nu un APK compilat.
Pentru a obține APK: Android Studio / Gradle cu JDK 17, apoi:
  ./gradlew assembleDebug
APK rezultat:
  app/build/outputs/apk/debug/app-debug.apk

Notă de streaming:
URL-urile originale sunt playlisturi .pls. Media3/ExoPlayer poate să nu redea playlistul PLS direct.
Dacă serverul nu livrează un format acceptat la URL-ul playlistului, trebuie folosit URL-ul audio direct
(ex. .mp3/.aac/.m3u8) sau un endpoint HLS/MP3 compatibil. Acest lucru trebuie verificat la testare.


BUILD DIN TELEFON PRIN GITHUB (fara PC):
1. Creeaza un repository nou pe github.com (butonul + -> New repository).
2. In repository, foloseste Add file -> Upload files si incarca toate fisierele din acest proiect,
   inclusiv folderul ascuns .github/workflows/build-apk.yml.
3. Apasa Commit changes.
4. Deschide tab-ul Actions -> workflow "Build Radio Big FM Alban APK" -> Run workflow.
5. Cand jobul devine verde, intra in sumarul rularii si descarca artifact-ul
   "Radio-Big-FM-Alban-debug". In arhiva vei gasi app-debug.apk.

Nota: GitHub poate necesita sa activezi Actions pentru repository. APK-ul debug este semnat
cu cheia de debug a buildului si poate fi instalat pentru test. Pentru distributie publica
este necesara o cheie de release proprie.


Actualizări: aplicația include butonul „Verifică actualizări”, care verifică ultima GitHub Release din ipnetro/Radio-blak. Pentru ca verificarea să găsească o versiune nouă, publică un Release și atașează APK-ul rezultat. Instalarea este confirmată manual de Android.

Actualizari: aplicatia verifica ultima GitHub Release la pornire si din meniul Verifica actualizari. Daca exista o versiune mai noua si Release-ul are un APK atasat, butonul Descarca APK deschide URL-ul direct al fisierului .apk. Instalarea este confirmata de Android dupa descarcare. Versiunea afisata foloseste BuildConfig.VERSION_NAME.
