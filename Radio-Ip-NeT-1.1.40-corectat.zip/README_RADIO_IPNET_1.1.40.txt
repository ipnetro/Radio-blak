Radio Ip-NeT — sursa 1.1.40

Versiune afișată: 1.1.40
Application ID: ro.ipnet
Version code: 1001040

Funcții păstrate în proiect:
- Favorite
- Istoric ascultare
- Control media prin notificare și ecran blocat (MediaSession)
- Now Playing, când streamul transmite metadate

Eliminate:
- Teme personalizabile (rămâne designul IP-NET negru-roșu)
- Egalizator

Cele trei posturi radio existente și verificarea actualizărilor sunt păstrate.
Cheia de semnare trebuie să fie aceeași cu cea folosită pentru APK-ul instalat, în secretele GitHub.
