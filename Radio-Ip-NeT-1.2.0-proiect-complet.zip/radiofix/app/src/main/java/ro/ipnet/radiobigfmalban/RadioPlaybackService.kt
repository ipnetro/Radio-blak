package ro.ipnet.radiobigfmalban

import androidx.media3.common.AudioAttributes
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.audiofx.Equalizer
import android.os.Build
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class RadioPlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private var equalizer: Equalizer? = null
    private val equalizerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val level = intent?.getIntExtra("level", 0) ?: return
            try {
                val eq = equalizer ?: return
                if (eq.numberOfBands > 0) eq.setBandLevel(0, level.coerceIn(eq.bandLevelRange[0].toInt(), eq.bandLevelRange[1].toInt()).toShort())
            } catch (_: Exception) { }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            setHandleAudioBecomingNoisy(true)
        }
        try { equalizer = Equalizer(0, player.audioSessionId).apply { enabled = true } } catch (_: Exception) { equalizer = null }
        val filter = IntentFilter("ro.ipnet.action.EQUALIZER")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(equalizerReceiver, filter, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(equalizerReceiver, filter)
        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    override fun onDestroy() {
        try { unregisterReceiver(equalizerReceiver) } catch (_: Exception) { }
        try { equalizer?.release() } catch (_: Exception) { }
        equalizer = null
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }
}
