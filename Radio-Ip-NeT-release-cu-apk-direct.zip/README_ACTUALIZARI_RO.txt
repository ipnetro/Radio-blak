RADIO IP-NET — ACTUALIZĂRI

applicationId = ro.ipnet
namespace = ro.ipnet
Versiunea de bază = 1.1.34
versionCode = 1001034

La pornire și la apăsarea „Verifică actualizări”:
- citește ultima versiune din GitHub Releases;
- dacă nu există versiune nouă, meniul arată „Aplicația este la zi — nu trebuie actualizată”;
- dacă există APK mai nou, îl descarcă și pornește instalarea Android.
Android cere confirmarea instalării; aplicațiile obișnuite nu se pot instala silențios.
Nu este necesară dezinstalarea la actualizările viitoare dacă applicationId și cheia de semnare rămân identice.

Pentru prima trecere de la vechiul applicationId la ro.ipnet, dezinstalează o singură dată aplicația veche și instalează prima versiune release.
Configurează cele patru GitHub Actions secrets conform fișierului Radio-Ip-NeT-GitHub-Secrets.txt.
Pune conținutul folderului proiectului în rădăcina repository-ului GitHub.
Creează tag-ul v1.1.34 pentru a publica prima versiune release.
Păstrează în siguranță radio-ipnet-release.jks și folosește aceeași cheie la fiecare release.
